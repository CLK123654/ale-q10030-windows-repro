CREATE OR REPLACE FUNCTION dispatch.prepare_outbox()
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  TRUNCATE TABLE
    dispatch.claim_audit,
    dispatch.dispatch_attempt,
    dispatch.endpoint_slot,
    dispatch.event_decision,
    dispatch.dispatch_job,
    dispatch.endpoint_policy
  RESTART IDENTITY CASCADE;

  INSERT INTO dispatch.endpoint_policy(
    endpoint_id,
    topic,
    active,
    max_in_flight,
    retry_profile,
    endpoint_kind
  )
  SELECT
    source.endpoint_id,
    source.topic,
    source.active,
    source.max_in_flight,
    string_to_array(source.retry_profile_text, '|')::integer[],
    source.endpoint_kind
  FROM dispatch.source_endpoint_policy AS source;

  INSERT INTO dispatch.endpoint_slot(endpoint_id, slot_no)
  SELECT policy.endpoint_id, slot_no
  FROM dispatch.endpoint_policy AS policy
  CROSS JOIN LATERAL generate_series(1, policy.max_in_flight) AS slot_no;

  WITH ranked_event AS (
    SELECT
      source.*,
      row_number() OVER (
        PARTITION BY source.dedupe_key
        ORDER BY source.created_at_utc, source.event_id
      ) AS dedupe_rank
    FROM dispatch.source_event AS source
  ),
  canonical_event AS (
    SELECT *
    FROM ranked_event
    WHERE dedupe_rank = 1
  )
  INSERT INTO dispatch.event_decision(
    event_id,
    endpoint_id,
    dedupe_key,
    decision,
    reason
  )
  SELECT
    ranked.event_id,
    NULL,
    ranked.dedupe_key,
    'suppressed',
    'duplicate_event'
  FROM ranked_event AS ranked
  WHERE ranked.dedupe_rank > 1

  UNION ALL

  SELECT
    canonical.event_id,
    NULL,
    canonical.dedupe_key,
    'suppressed',
    'invalid_payload'
  FROM canonical_event AS canonical
  WHERE NOT canonical.payload_valid

  UNION ALL

  SELECT
    canonical.event_id,
    NULL,
    canonical.dedupe_key,
    'suppressed',
    'no_active_subscription'
  FROM canonical_event AS canonical
  WHERE canonical.payload_valid
    AND NOT EXISTS (
      SELECT 1
      FROM dispatch.endpoint_policy AS policy
      WHERE policy.active
        AND policy.topic = canonical.topic
    )

  UNION ALL

  SELECT
    canonical.event_id,
    policy.endpoint_id,
    canonical.dedupe_key,
    CASE
      WHEN policy.endpoint_kind = 'email' AND NOT canonical.email_opt_in
        THEN 'suppressed'
      ELSE 'created_job'
    END,
    CASE
      WHEN policy.endpoint_kind = 'email' AND NOT canonical.email_opt_in
        THEN 'recipient_email_opt_out'
      ELSE 'active_subscription'
    END
  FROM canonical_event AS canonical
  JOIN dispatch.endpoint_policy AS policy
    ON policy.active
   AND policy.topic = canonical.topic
  WHERE canonical.payload_valid;

  INSERT INTO dispatch.dispatch_job(
    endpoint_id,
    dedupe_key,
    event_id,
    topic,
    priority,
    source_created_at_utc,
    updated_at_utc
  )
  SELECT
    decision.endpoint_id,
    decision.dedupe_key,
    source.event_id,
    source.topic,
    source.priority,
    source.created_at_utc,
    source.created_at_utc
  FROM dispatch.event_decision AS decision
  JOIN dispatch.source_event AS source
    ON source.event_id = decision.event_id
  WHERE decision.decision = 'created_job';

  UPDATE dispatch.dispatch_job AS job
  SET state = source.state,
      attempt_no = source.attempt_no,
      lease_owner = source.lease_owner,
      lease_until_utc = source.lease_until_utc,
      next_due_at_utc = source.next_due_at_utc,
      provider_message_id = source.provider_message_id,
      updated_at_utc = COALESCE(
        source.lease_until_utc,
        source.next_due_at_utc,
        job.source_created_at_utc
      )
  FROM dispatch.source_existing_state AS source
  WHERE job.endpoint_id = source.endpoint_id
    AND job.dedupe_key = source.dedupe_key;

  WITH leased_job AS (
    SELECT
      job.endpoint_id,
      job.dedupe_key,
      job.lease_owner,
      job.lease_until_utc,
      row_number() OVER (
        PARTITION BY job.endpoint_id
        ORDER BY job.lease_until_utc, job.dedupe_key
      ) AS slot_no
    FROM dispatch.dispatch_job AS job
    WHERE job.state = 'leased'
  )
  UPDATE dispatch.endpoint_slot AS slot
  SET dedupe_key = leased.dedupe_key,
      lease_owner = leased.lease_owner,
      lease_until_utc = leased.lease_until_utc
  FROM leased_job AS leased
  WHERE slot.endpoint_id = leased.endpoint_id
    AND slot.slot_no = leased.slot_no;

  IF EXISTS (
    SELECT 1
    FROM dispatch.dispatch_job AS job
    WHERE job.state = 'leased'
      AND NOT EXISTS (
        SELECT 1
        FROM dispatch.endpoint_slot AS slot
        WHERE slot.endpoint_id = job.endpoint_id
          AND slot.dedupe_key = job.dedupe_key
      )
  ) THEN
    RAISE EXCEPTION 'existing leased jobs exceed endpoint capacity';
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION dispatch.claim_dispatch_batch(
  p_wave_id text,
  p_worker_id text,
  p_limit integer,
  p_now timestamptz
)
RETURNS TABLE (
  endpoint_id text,
  dedupe_key text,
  event_id text,
  attempt_no integer,
  lease_until_utc timestamptz
)
LANGUAGE plpgsql
AS $$
DECLARE
  selected_job record;
  selected_slot integer;
  candidate_count integer := 0;
  claimed_count integer := 0;
  seen_keys text[] := ARRAY[]::text[];
BEGIN
  IF p_limit <= 0 THEN
    RAISE EXCEPTION 'claim limit must be positive';
  END IF;

  LOOP
    EXIT WHEN claimed_count >= p_limit;

    SELECT job.*
    INTO selected_job
    FROM dispatch.dispatch_job AS job
    WHERE (
        job.state = 'queued'
        OR (job.state = 'retry_due' AND job.next_due_at_utc <= p_now)
        OR (job.state = 'leased' AND job.lease_until_utc <= p_now)
      )
      AND NOT (
        job.endpoint_id || chr(31) || job.dedupe_key = ANY(seen_keys)
      )
    ORDER BY
      job.priority DESC,
      COALESCE(job.next_due_at_utc, job.source_created_at_utc),
      job.event_id,
      job.endpoint_id
    FOR UPDATE SKIP LOCKED
    LIMIT 1;

    EXIT WHEN NOT FOUND;

    candidate_count := candidate_count + 1;
    seen_keys := array_append(
      seen_keys,
      selected_job.endpoint_id || chr(31) || selected_job.dedupe_key
    );

    selected_slot := NULL;
    SELECT slot.slot_no
    INTO selected_slot
    FROM dispatch.endpoint_slot AS slot
    WHERE slot.endpoint_id = selected_job.endpoint_id
      AND (
        slot.dedupe_key IS NULL
        OR slot.lease_until_utc <= p_now
      )
    ORDER BY
      CASE WHEN slot.dedupe_key = selected_job.dedupe_key THEN 0 ELSE 1 END,
      slot.slot_no
    FOR UPDATE SKIP LOCKED
    LIMIT 1;

    IF selected_slot IS NULL THEN
      INSERT INTO dispatch.claim_audit(
        wave_id,
        candidate_rank,
        worker_id,
        endpoint_id,
        dedupe_key,
        event_id,
        decision
      )
      VALUES (
        p_wave_id,
        candidate_count,
        p_worker_id,
        selected_job.endpoint_id,
        selected_job.dedupe_key,
        selected_job.event_id,
        'endpoint_at_capacity'
      );
      CONTINUE;
    END IF;

    UPDATE dispatch.dispatch_job AS job
    SET state = 'leased',
        attempt_no = job.attempt_no + 1,
        lease_owner = p_worker_id,
        lease_until_utc = p_now + interval '5 minutes',
        updated_at_utc = p_now
    WHERE job.endpoint_id = selected_job.endpoint_id
      AND job.dedupe_key = selected_job.dedupe_key
    RETURNING
      job.endpoint_id,
      job.dedupe_key,
      job.event_id,
      job.attempt_no,
      job.lease_until_utc
    INTO
      endpoint_id,
      dedupe_key,
      event_id,
      attempt_no,
      lease_until_utc;

    UPDATE dispatch.endpoint_slot AS slot
    SET dedupe_key = selected_job.dedupe_key,
        lease_owner = p_worker_id,
        lease_until_utc = p_now + interval '5 minutes'
    WHERE slot.endpoint_id = selected_job.endpoint_id
      AND slot.slot_no = selected_slot;

    INSERT INTO dispatch.dispatch_attempt(
      endpoint_id,
      dedupe_key,
      attempt_no,
      worker_id,
      claimed_at_utc,
      lease_until_utc
    )
    VALUES (
      endpoint_id,
      dedupe_key,
      attempt_no,
      p_worker_id,
      p_now,
      lease_until_utc
    );

    INSERT INTO dispatch.claim_audit(
      wave_id,
      candidate_rank,
      worker_id,
      endpoint_id,
      dedupe_key,
      event_id,
      decision,
      attempt_no,
      claimed_at_utc,
      lease_until_utc
    )
    VALUES (
      p_wave_id,
      candidate_count,
      p_worker_id,
      endpoint_id,
      dedupe_key,
      event_id,
      'claimed',
      attempt_no,
      p_now,
      lease_until_utc
    );

    claimed_count := claimed_count + 1;
    RETURN NEXT;
  END LOOP;
END;
$$;

CREATE OR REPLACE FUNCTION dispatch.finalize_dispatch(
  p_worker_id text,
  p_endpoint_id text,
  p_dedupe_key text,
  p_attempt_no integer,
  p_finished_at timestamptz,
  p_outcome dispatch.delivery_outcome,
  p_status_code integer,
  p_provider_message_id text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  current_job dispatch.dispatch_job%ROWTYPE;
  retry_delay_minutes integer;
BEGIN
  SELECT job.*
  INTO current_job
  FROM dispatch.dispatch_job AS job
  WHERE job.endpoint_id = p_endpoint_id
    AND job.dedupe_key = p_dedupe_key
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'dispatch job not found';
  END IF;

  IF current_job.state = 'sent'
     AND p_outcome = 'sent'
     AND current_job.attempt_no = p_attempt_no
     AND current_job.provider_message_id IS NOT DISTINCT FROM p_provider_message_id THEN
    RETURN;
  END IF;

  IF current_job.state <> 'leased'
     OR current_job.lease_owner <> p_worker_id
     OR current_job.attempt_no <> p_attempt_no
     OR current_job.lease_until_utc < p_finished_at THEN
    RAISE EXCEPTION 'receipt does not belong to the active lease';
  END IF;

  UPDATE dispatch.dispatch_attempt AS attempt
  SET finished_at_utc = p_finished_at,
      outcome = p_outcome,
      status_code = p_status_code,
      provider_message_id = p_provider_message_id
  WHERE attempt.endpoint_id = p_endpoint_id
    AND attempt.dedupe_key = p_dedupe_key
    AND attempt.attempt_no = p_attempt_no
    AND attempt.worker_id = p_worker_id
    AND attempt.finished_at_utc IS NULL;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'receipt attempt is stale or already completed';
  END IF;

  IF p_outcome = 'sent' THEN
    UPDATE dispatch.dispatch_job AS job
    SET state = 'sent',
        lease_owner = NULL,
        lease_until_utc = NULL,
        next_due_at_utc = NULL,
        provider_message_id = p_provider_message_id,
        last_status_code = p_status_code,
        updated_at_utc = p_finished_at
    WHERE job.endpoint_id = p_endpoint_id
      AND job.dedupe_key = p_dedupe_key;
  ELSE
    SELECT policy.retry_profile[
      LEAST(p_attempt_no, cardinality(policy.retry_profile))
    ]
    INTO retry_delay_minutes
    FROM dispatch.endpoint_policy AS policy
    WHERE policy.endpoint_id = p_endpoint_id;

    UPDATE dispatch.dispatch_job AS job
    SET state = 'retry_due',
        lease_owner = NULL,
        lease_until_utc = NULL,
        next_due_at_utc = p_finished_at
          + make_interval(mins => retry_delay_minutes),
        provider_message_id = NULL,
        last_status_code = p_status_code,
        updated_at_utc = p_finished_at
    WHERE job.endpoint_id = p_endpoint_id
      AND job.dedupe_key = p_dedupe_key;
  END IF;

  UPDATE dispatch.endpoint_slot AS slot
  SET dedupe_key = NULL,
      lease_owner = NULL,
      lease_until_utc = NULL
  WHERE slot.endpoint_id = p_endpoint_id
    AND slot.dedupe_key = p_dedupe_key
    AND slot.lease_owner = p_worker_id;
END;
$$;

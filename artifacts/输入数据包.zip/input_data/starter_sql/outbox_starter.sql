-- Broken starter: this update can block competing dispatchers and ignores endpoint caps.
UPDATE outbox_job
SET state = 'leased',
    lease_owner = :worker_id,
    lease_until_utc = :now + interval '5 minutes'
WHERE id IN (
  SELECT id
  FROM outbox_job
  WHERE state IN ('queued','retry_due')
  ORDER BY priority DESC
  LIMIT :limit
);

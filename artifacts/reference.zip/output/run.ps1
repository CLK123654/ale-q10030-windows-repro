[CmdletBinding()]
param(
  [string]$InputRoot = (Join-Path $PSScriptRoot '..\input_data'),
  [string]$DatabaseName = 'outbox_staging',
  [string]$PgHostName = '127.0.0.1',
  [int]$PgPort = 5432,
  [string]$PgUser = 'postgres',
  [string]$PgPassword = 'root',
  [string]$PsqlPath = ''
)

$ErrorActionPreference = 'Stop'
$env:PGPASSWORD = $PgPassword

if ([string]::IsNullOrWhiteSpace($PsqlPath)) {
  if ($env:PGBIN) {
    $PsqlPath = Join-Path $env:PGBIN 'psql.exe'
    if (-not (Test-Path $PsqlPath)) {
      $PsqlPath = Join-Path $env:PGBIN 'psql'
    }
  } else {
    $PsqlPath = (Get-Command psql -ErrorAction Stop).Source
  }
}

$OutputRoot = $PSScriptRoot
$SqlRoot = Join-Path $OutputRoot 'sql'
$ReportRoot = Join-Path $OutputRoot 'reports'
New-Item -ItemType Directory -Force -Path $ReportRoot | Out-Null

function Invoke-Psql([string[]]$CommandArguments) {
  & $PsqlPath '-X' '-v' 'ON_ERROR_STOP=1' '-h' $PgHostName '-p' $PgPort '-U' $PgUser '-d' $DatabaseName @CommandArguments
  if ($LASTEXITCODE -ne 0) {
    throw "psql failed with exit code $LASTEXITCODE"
  }
}

Push-Location $SqlRoot
try {
  Invoke-Psql @('-f', 'schema.sql')
  Invoke-Psql @('-f', 'outbox_runtime.sql')
} finally {
  Pop-Location
}

$InputDataRoot = Join-Path $InputRoot 'data'
Push-Location $InputDataRoot
try {
  Invoke-Psql @('-c', "\copy dispatch.source_event(event_id,topic,dedupe_key,created_at_utc,priority,payload_valid,email_opt_in,payload_bytes) FROM 'events.csv' CSV HEADER")
  Invoke-Psql @('-c', "\copy dispatch.source_endpoint_policy(endpoint_id,topic,active,max_in_flight,retry_profile_text,endpoint_kind) FROM 'endpoint_policy.csv' CSV HEADER")
  Invoke-Psql @('-c', "\copy dispatch.source_existing_state(endpoint_id,dedupe_key,state,attempt_no,lease_owner,lease_until_utc,next_due_at_utc,provider_message_id) FROM 'existing_dispatch_state.csv' CSV HEADER")
  Invoke-Psql @('-c', "\copy dispatch.source_delivery_result(wave_id,worker_id,endpoint_id,dedupe_key,delivered_at_utc,outcome,status_code,provider_message_id) FROM 'delivery_results.csv' CSV HEADER")
} finally {
  Pop-Location
}

Invoke-Psql @('-c', 'SELECT dispatch.prepare_outbox();')
Invoke-Psql @('-c', "SELECT * FROM dispatch.claim_dispatch_batch('W1','dispatcher-a',3,'2026-07-30T10:00:00Z');")
Invoke-Psql @('-c', "SELECT dispatch.finalize_dispatch(source.worker_id,source.endpoint_id,source.dedupe_key,job.attempt_no,source.delivered_at_utc,source.outcome,source.status_code,source.provider_message_id) FROM dispatch.source_delivery_result AS source JOIN dispatch.dispatch_job AS job USING(endpoint_id,dedupe_key) WHERE source.wave_id='W1';")
Invoke-Psql @('-c', "SELECT * FROM dispatch.claim_dispatch_batch('W2','dispatcher-b',3,'2026-07-30T10:03:50Z');")
Invoke-Psql @('-c', "SELECT dispatch.finalize_dispatch(source.worker_id,source.endpoint_id,source.dedupe_key,job.attempt_no,source.delivered_at_utc,source.outcome,source.status_code,source.provider_message_id) FROM dispatch.source_delivery_result AS source JOIN dispatch.dispatch_job AS job USING(endpoint_id,dedupe_key) WHERE source.wave_id='W2';")

$EventDecisionQuery = @'
SELECT event_id,coalesce(endpoint_id,'') AS endpoint_id,dedupe_key,decision,reason FROM dispatch.event_decision ORDER BY decision_id
'@
$ClaimWaveQuery = @'
SELECT wave_id,candidate_rank,worker_id,endpoint_id,dedupe_key,event_id,decision,attempt_no,to_char(claimed_at_utc AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"') AS claimed_at_utc,to_char(lease_until_utc AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"') AS lease_until_utc FROM dispatch.claim_audit ORDER BY audit_id
'@
$FinalStateQuery = @'
SELECT endpoint_id,dedupe_key,event_id,state AS final_state,attempt_no,to_char(next_due_at_utc AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"') AS next_due_at_utc,lease_owner,to_char(lease_until_utc AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"') AS lease_until_utc,provider_message_id,last_status_code FROM dispatch.dispatch_job ORDER BY endpoint_id,dedupe_key
'@
$EndpointSummaryQuery = @'
SELECT endpoint_id,count(*) FILTER (WHERE state='queued') AS queued_count,count(*) FILTER (WHERE state='leased') AS leased_count,count(*) FILTER (WHERE state='retry_due') AS retry_due_count,count(*) FILTER (WHERE state='sent') AS sent_count,count(*) AS total_count FROM dispatch.dispatch_job GROUP BY endpoint_id ORDER BY endpoint_id
'@

Push-Location $ReportRoot
try {
  Invoke-Psql @('-c', "\copy ($EventDecisionQuery) TO 'event_decision.csv' CSV HEADER")
  Invoke-Psql @('-c', "\copy ($ClaimWaveQuery) TO 'claim_wave.csv' CSV HEADER")
  Invoke-Psql @('-c', "\copy ($FinalStateQuery) TO 'final_dispatch_state.csv' CSV HEADER")
  Invoke-Psql @('-c', "\copy ($EndpointSummaryQuery) TO 'endpoint_summary.csv' CSV HEADER")
} finally {
  Pop-Location
}

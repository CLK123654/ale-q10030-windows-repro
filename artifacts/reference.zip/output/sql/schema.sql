DROP SCHEMA IF EXISTS dispatch CASCADE;
CREATE SCHEMA dispatch;

CREATE TYPE dispatch.job_state AS ENUM ('queued', 'leased', 'retry_due', 'sent', 'dead');
CREATE TYPE dispatch.delivery_outcome AS ENUM ('sent', 'failed');

CREATE TABLE dispatch.source_event (
  event_id text PRIMARY KEY,
  topic text NOT NULL,
  dedupe_key text NOT NULL,
  created_at_utc timestamptz NOT NULL,
  priority integer NOT NULL CHECK (priority BETWEEN 0 AND 100),
  payload_valid boolean NOT NULL,
  email_opt_in boolean NOT NULL,
  payload_bytes integer NOT NULL CHECK (payload_bytes >= 0)
);

CREATE TABLE dispatch.source_endpoint_policy (
  endpoint_id text PRIMARY KEY,
  topic text NOT NULL,
  active boolean NOT NULL,
  max_in_flight integer NOT NULL CHECK (max_in_flight > 0),
  retry_profile_text text NOT NULL,
  endpoint_kind text NOT NULL CHECK (endpoint_kind IN ('webhook', 'email'))
);

CREATE TABLE dispatch.source_existing_state (
  endpoint_id text NOT NULL,
  dedupe_key text NOT NULL,
  state dispatch.job_state NOT NULL,
  attempt_no integer NOT NULL CHECK (attempt_no >= 0),
  lease_owner text,
  lease_until_utc timestamptz,
  next_due_at_utc timestamptz,
  provider_message_id text,
  PRIMARY KEY (endpoint_id, dedupe_key)
);

CREATE TABLE dispatch.source_delivery_result (
  wave_id text NOT NULL,
  worker_id text NOT NULL,
  endpoint_id text NOT NULL,
  dedupe_key text NOT NULL,
  delivered_at_utc timestamptz NOT NULL,
  outcome dispatch.delivery_outcome NOT NULL,
  status_code integer NOT NULL,
  provider_message_id text,
  PRIMARY KEY (wave_id, endpoint_id, dedupe_key)
);

CREATE TABLE dispatch.endpoint_policy (
  endpoint_id text PRIMARY KEY,
  topic text NOT NULL,
  active boolean NOT NULL,
  max_in_flight integer NOT NULL CHECK (max_in_flight > 0),
  retry_profile integer[] NOT NULL CHECK (cardinality(retry_profile) > 0),
  endpoint_kind text NOT NULL CHECK (endpoint_kind IN ('webhook', 'email'))
);

CREATE TABLE dispatch.dispatch_job (
  endpoint_id text NOT NULL REFERENCES dispatch.endpoint_policy(endpoint_id),
  dedupe_key text NOT NULL,
  event_id text NOT NULL REFERENCES dispatch.source_event(event_id),
  topic text NOT NULL,
  priority integer NOT NULL,
  source_created_at_utc timestamptz NOT NULL,
  state dispatch.job_state NOT NULL DEFAULT 'queued',
  attempt_no integer NOT NULL DEFAULT 0 CHECK (attempt_no >= 0),
  next_due_at_utc timestamptz,
  lease_owner text,
  lease_until_utc timestamptz,
  provider_message_id text,
  last_status_code integer,
  updated_at_utc timestamptz NOT NULL,
  PRIMARY KEY (endpoint_id, dedupe_key)
);

CREATE TABLE dispatch.dispatch_attempt (
  endpoint_id text NOT NULL,
  dedupe_key text NOT NULL,
  attempt_no integer NOT NULL,
  worker_id text NOT NULL,
  claimed_at_utc timestamptz NOT NULL,
  lease_until_utc timestamptz NOT NULL,
  finished_at_utc timestamptz,
  outcome dispatch.delivery_outcome,
  status_code integer,
  provider_message_id text,
  PRIMARY KEY (endpoint_id, dedupe_key, attempt_no),
  FOREIGN KEY (endpoint_id, dedupe_key)
    REFERENCES dispatch.dispatch_job(endpoint_id, dedupe_key)
);

CREATE TABLE dispatch.endpoint_slot (
  endpoint_id text NOT NULL REFERENCES dispatch.endpoint_policy(endpoint_id),
  slot_no integer NOT NULL CHECK (slot_no > 0),
  dedupe_key text,
  lease_owner text,
  lease_until_utc timestamptz,
  PRIMARY KEY (endpoint_id, slot_no),
  CHECK (
    (dedupe_key IS NULL AND lease_owner IS NULL AND lease_until_utc IS NULL)
    OR
    (dedupe_key IS NOT NULL AND lease_owner IS NOT NULL AND lease_until_utc IS NOT NULL)
  )
);

CREATE UNIQUE INDEX endpoint_slot_job_once
  ON dispatch.endpoint_slot(endpoint_id, dedupe_key)
  WHERE dedupe_key IS NOT NULL;

CREATE TABLE dispatch.event_decision (
  decision_id bigserial PRIMARY KEY,
  event_id text NOT NULL,
  endpoint_id text,
  dedupe_key text NOT NULL,
  decision text NOT NULL CHECK (decision IN ('created_job', 'suppressed')),
  reason text NOT NULL
);

CREATE TABLE dispatch.claim_audit (
  audit_id bigserial PRIMARY KEY,
  wave_id text NOT NULL,
  candidate_rank integer NOT NULL,
  worker_id text NOT NULL,
  endpoint_id text NOT NULL,
  dedupe_key text NOT NULL,
  event_id text NOT NULL,
  decision text NOT NULL CHECK (decision IN ('claimed', 'endpoint_at_capacity')),
  attempt_no integer,
  claimed_at_utc timestamptz,
  lease_until_utc timestamptz
);

CREATE INDEX dispatch_due_claim_idx
  ON dispatch.dispatch_job(
    priority DESC,
    source_created_at_utc,
    event_id,
    endpoint_id
  )
  WHERE state IN ('queued', 'retry_due', 'leased');

CREATE INDEX dispatch_active_lease_idx
  ON dispatch.dispatch_job(endpoint_id, lease_until_utc)
  WHERE state = 'leased';

CREATE INDEX dispatch_attempt_worker_idx
  ON dispatch.dispatch_attempt(worker_id, claimed_at_utc DESC);
